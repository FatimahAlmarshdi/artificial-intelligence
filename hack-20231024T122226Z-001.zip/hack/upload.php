<?php
if(isset($_FILES['fileToUpload'])){
    move_uploaded_file($_FILES['fileToUpload']['tmp_name'], "images/image.jpg");
    $image = curl_file_create('images/image.jpg');
    $data = array('image' => $image);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://127.0.0.1:5000/im_size");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_TIMEOUT, 300);
    $output = curl_exec($ch);
    curl_close($ch);
    echo $output;
}
else{
    echo "image not found!";
}

?>