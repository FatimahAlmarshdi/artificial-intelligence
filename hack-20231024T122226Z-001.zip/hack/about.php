<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css"/>

    <title>Document</title>
</head>
<body>
<section class="about">
        <div class="about-img">
            <img src="images/des1.png">
        </div>
        <div class="about-text">
          
            <p>A website specialized in analyzing children's personalities and identifying strengths and weaknesses and any problems or disorders through their drawings. The site scans the image and gives an analysis based on the curvature of the line, the speed of drawing and the force of pressure of the pen on the paper..</p>
            <button class="main-btn">Read More</button>
        </div>
    </section>
</body>
</html>