<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css"/>
    <link rel="stylesheet" href="users.css"/>
    <title>Document</title>
</head>
<body>
    
<div class="wrapper">
        <h1>specialists  </h1>
        <div class="our_team">
            <div class="team_member">
              <div class="member_img">
                 <img src="https://i.imgur.com/2Necikc.png" alt="our_team">
                <div class="social_media">
                   <div class="facebook item"><i class="fab fa-facebook-f"></i></div>
                   <div class="twitter item"><i class="fab fa-twitter"></i></div>
                   <div class="instagram item"><i class="fab fa-instagram"></i></div>
                 </div>
              </div>
              <h3>ahmed</h3>
              <p>   Consultant of family, children, mental health and addiction treatment. Holds 6 Saudi, Arab, Australian and American fellowships</p>
            </div>
            <div class="team_member">
               <div class="member_img">
                 <img src="https://i.imgur.com/JzUIF4o.png" alt="our_team">
                 <div class="social_media">
                   <div class="facebook item"><i class="fab fa-facebook-f"></i></div>
                   <div class="twitter item"><i class="fab fa-twitter"></i></div>
                   <div class="instagram item"><i class="fab fa-instagram"></i></div>
                 </div>
              </div>
              <h3> khaled</h3>
              <p>Psychologist, MA in Psychological Counseling from King Abdulaziz University - Diploma in Family Counseling from Boston</p>
          </div>
            <div class="team_member">
               <div class="member_img">
                 <img src="https://i.imgur.com/Ctwf8HA.png" alt="our_team">
                 <div class="social_media">
                   <div class="facebook item"><i class="fab fa-facebook-f"></i></div>
                   <div class="twitter item"><i class="fab fa-twitter"></i></div>
                   <div class="instagram item"><i class="fab fa-instagram"></i></div>
                 </div>
              </div>
              <h3>harry dickens</h3>
              <p>Consultant psychiatrist, holds a Saudi fellowship "PhD" in psychiatry.</p>
          </div>
      
    </div>
</body>
</html>