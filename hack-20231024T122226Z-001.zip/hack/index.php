
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Dynamic Website</title>
    <link rel="stylesheet" href="style.css"/>
    <link rel="stylesheet" href="users.css"/>
    <link rel="stylesheet" href="conutact.css"/>


    <link href='//fonts.googleapis.com/css?family=Open+Sans:700,600' rel='stylesheet' type='text/css'>

</head>
<body >
<head>
    <!--using FontAwesome---------------->
  <script src="https://kit.fontawesome.com/c8e4d183c2.js" crossorigin="anonymous"></script>
  </head>
    <header class="main" >
        <nav>
            <a href="#" class="logo">
                <img src="images/logo1.png" width="100px"/>
            </a>

            <?php $link_address1 = 'about.php';


$link_address2 = 'SPECIALISTS.php';
$link_address3 = 'Contact.php'; ?> 


            <ul class="menu">
                <li><a href="#" class="active">home</a></li>
                <li><a href="SPECIALISTS.php">Specialists</a></li>
                <li><a href="about.php">About</a></li>

                <li><a href="Contact.php">Contact</a></li> 

               
					
               

              	
                 
                <style>
/* Style The Dropdown Button */
.dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: white;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #f1f1f1}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {
  display: block;
}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {
  background-color: #3e8e41;
}
</style>

<div class="dropdown">
  <button class="dropbtn">language </button>
  <div class="dropdown-content">
  <?php
                $url= "LANGUGE"; ?>
    <a href="langs_en.php"> Arabic</a>
    <a href="#">English</a>
  </div>
</div>
            </ul>
        </nav>
        <h1>Let's detect emotion in your child's drawing</h1>
       
    </header>
   
       
    </div> 

    

    <section class="features">
      
<form action="upload.php" method="post" enctype="multipart/form-data">
  Select image to upload:
  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Upload Image" name="submit">
</form>
    </section>
    <section> 
    <div class="wrapper">
        <h1>specialists  </h1>
        <div class="our_team">
            <div class="team_member">
              <div class="member_img">
                <div class="social_media">
                   <div class="facebook item"><i class="fab fa-facebook-f"></i></div>
                   <div class="twitter item"><i class="fab fa-twitter"></i></div>
                   <div class="instagram item"><i class="fab fa-instagram"></i></div>
                 </div>
              </div>
              <h3>ahmed</h3>
              <p>   Consultant of family, children, mental health and addiction treatment. Holds 6 Saudi, Arab, Australian and American fellowships</p>
            </div>
            <div class="team_member">
               <div class="member_img">
                 <div class="social_media">
                   <div class="facebook item"><i class="fab fa-facebook-f"></i></div>
                   <div class="twitter item"><i class="fab fa-twitter"></i></div>
                   <div class="instagram item"><i class="fab fa-instagram"></i></div>
                 </div>
              </div>
              <h3> khaled</h3>
              <p>Psychologist, MA in Psychological Counseling from King Abdulaziz University - Diploma in Family Counseling from Boston</p>
          </div>
            <div class="team_member">
               <div class="member_img">
                 <div class="social_media">
                   <div class="facebook item"><i class="fab fa-facebook-f"></i></div>
                   <div class="twitter item"><i class="fab fa-twitter"></i></div>
                   <div class="instagram item"><i class="fab fa-instagram"></i></div>
                 </div>
              </div>
              <h3>harry dickens</h3>
              <p>Consultant psychiatrist, holds a Saudi fellowship "PhD" in psychiatry.</p>
          </div>
      
    </div>
    
    </sesection>

    <section class="about">
        <div class="about-img">
            <img src="images/des1.png">
        </div>
        <div class="about-text">
          
            <p>A website specialized in analyzing children's personalities and identifying strengths and weaknesses and any problems or disorders through their drawings. The site scans the image and gives an analysis based on the curvature of the line, the speed of drawing and the force of pressure of the pen on the paper..</p>
            <button class="main-btn">Read More</button>
        </div>
    </section>

    
    <section clas="contact"> <div class="container">
    <div class="content">
      <div class="left-side">
        <div class="address details">
          <i class="fas fa-map-marker-alt"></i>
          <div class="topic">Address</div>
          <div class="text-one">Surkhet, NP12</div>
          <div class="text-two">Birendranagar 06</div>
        </div>
        <div class="phone details">
          <i class="fas fa-phone-alt"></i>
          <div class="topic">Phone</div>
          <div class="text-one">+0098 9893 5647</div>
          <div class="text-two">+0096 3434 5678</div>
        </div>
        <div class="email details">
          <i class="fas fa-envelope"></i>
          <div class="topic">Email</div>
          <div class="text-one">codinglab@gmail.com</div>
          <div class="text-two">info.codinglab@gmail.com</div>
        </div>
      </div>
      <div class="right-side">
        <div class="topic-text">Send us a message</div>
        <p>If you have any work from me or any types of quries related to my tutorial, you can send me message from here. It's my pleasure to help you.</p>
      <form action="#">
        <div class="input-box">
          <input type="text" placeholder="Enter your name">
        </div>
        <div class="input-box">
          <input type="text" placeholder="Enter your email">
        </div>
        <div class="input-box message-box">
          
        </div>
        <div class="button">
          <input type="button" value="Send Now" >
        </div>
      </form>
    </div>
    </div>
  </div> </section>
    </footer>
    
         <br>

         <br>
         <section> <div class="content">
      <div class="card one">
        <div class="top">
          <div class="title">Basic</div>
          <div class="price-sec">
            <span class="dollar">$</span>
            <span class="price">14</span>
            <span class="decimal">.99</span>
          </div>
        </div>
        <div class="info">Limited features you will get on this package or plan</div>
        <div class="details">
          <div class="one">
            <span>One Addons Domain</span>
            <i class="fas fa-check"></i>
          </div>
          <div class="one">
            <span>100GB Local Storage</span>
            <i class="fas fa-check"></i>
          </div>
          <div class="one">
            <span>Lifetime Tech Support</span>
            <i class="fas fa-times"></i>
          </div>
          <div class="one">
            <span>Unlimited Data Transfer</span>
            <i class="fas fa-times"></i>
          </div>
          <button>Purchase</button>
        </div>
      </div>
      <div class="card two">
        <div class="top">
          <div class="title">Extended</div>
          <div class="price-sec">
            <span class="dollar">$</span>
            <span class="price">16</span>
            <span class="decimal">.99</span>
          </div>
        </div>
        <div class="info">Only some features you will get on this package or plan</div>
        <div class="details">
          <div class="one">
            <span>Five Addons Domain</span>
            <i class="fas fa-check"></i>
          </div>
          <div class="one">
            <span>200GB Local Storage</span>
            <i class="fas fa-check"></i>
          </div>
          <div class="one">
            <span>Lifetime Tech Support</span>
            <i class="fas fa-check"></i>
          </div>
          <div class="one">
            <span>Unlimited Data Transfer</span>
            <i class="fas fa-times"></i>
          </div>
          <button>Purchase</button>
        </div>
      </div>
      <div class="card three">
        <div class="top">
          <div class="title">Premium</div>
          <div class="price-sec">
            <span class="dollar">$</span>
            <span class="price">18</span>
            <span class="decimal">.99</span>
          </div>
        </div>
        <div class="info">All features you will get on this package or plan</div>
        <div class="details">
          <div class="one">
            <span>10 Addons Domain</span>
            <i class="fas fa-check"></i>
          </div>
          <div class="one">
            <span>Unlimited Local Storage</span>
            <i class="fas fa-check"></i>
          </div>
          <div class="one">
            <span>Lifetime Tech Support</span>
            <i class="fas fa-check"></i>
          </div>
          <div class="one">
            <span>Unlimited Data Transfer</span>
            <i class="fas fa-check"></i>
          </div>
          <button>Purchase</button>
        </div>
      </div>
    </div>
    
    </section>
<footer class="footer">
    <div class="waves">
      <div class="wave" id="wave1"></div>
      <div class="wave" id="wave2"></div>
      <div class="wave" id="wave3"></div>
      <div class="wave" id="wave4"></div>
    </div>
    <ul class="social-icon">
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-facebook"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-twitter"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-linkedin"></ion-icon>
        </a></li>
      <li class="social-icon__item"><a class="social-icon__link" href="#">
          <ion-icon name="logo-instagram"></ion-icon>
        </a></li>
    </ul>
    <ul class="menu">
      <li class="menu__item"><a class="menu__link" href="<?php include_once " home.php"; ?>"> Home</a></li>
      <li class="menu__item"><a class="menu__link" href="#">About</a></li>
      <li class="menu__item"><a class="menu__link" href="#">Services</a></li>
      <li class="menu__item"><a class="menu__link" href="#">Team</a></li>
      <li class="menu__item"><a class="menu__link" href="#">Contact</a></li>

    </ul>
    <p>&copy;2023 nameweb  | All Rights Reserved</p>
  </footer>
  
  
</body>
</html>